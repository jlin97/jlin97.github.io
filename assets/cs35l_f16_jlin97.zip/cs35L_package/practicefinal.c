int g_divisorCount;

struct package {
    int start;
    int end;
};

/* Returns 1 if the given number is prime, 0 otherwise */
int countDivisors(long long number)
{
	g_divisorCount = 0;
	int nthreads = 3;
	long long i;

	pthreads_t threads[nthreads];
	struct package current[nthreads];

	int width = (number/2)-1 / nthreads; // if 18, width=2, R=4
	int j = 0;
	for(j = 0; j < nthreads-1; j++){
		current[j].start = (width*j);
		current[j].end = width*(j+1);
		ret = pthread_create( &threads[j], NULL, divided_load, &current[j] );
        if(ret){
            fprintf( stderr, "Error creating threads. Error: %d\n", ret);
            exit(-1);
        }
	}

	current[nthreads-1].start = width_for_thread*(nthreads-1);
    current[nthreads-1].end = current[nthreads-1].start+width_for_thread+(width%nthreads);
	ret = pthread_create( &threads[nthreads-1], NULL, divided_load, &current[nthreads-1] );
    if(ret){
    	fprintf( stderr, "Error creating threads. Error: %d\n", ret);
    	exit(-1);
    }
	
	for(int i = 0; i < nthreads; i++){
    	int ret = pthread_join(threads[i], NULL);
    	if(ret){
    		fprintf(stderr, "Error freeing threads. Error: %d\n", ret);
    		exit(-1);
    	}
    }
    
	return g_divisorCount;
}

int dividedLoad(void *package){
    struct package context = *(struct package *)current_item;
	for(i = 2+context.start; i < 2+context.end; i++)
	{
		if(number % i == 0)
			g_divisorCount++;
		}
}