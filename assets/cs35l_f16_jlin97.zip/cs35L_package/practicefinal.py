#!/usr/bin/python

import sys, locale

class Point3:
    def __init__(self, x, y, z):
        self.x = x
        self.y = y
        self.z = z

    def distance2(self, newp):
        x3 = int(newp.x) - int(self.x)
        y3 = int(newp.y) - int(self.y)
        z3 = int(newp.z) - int(self.z)
        return (x3*x3) + (y3*y3) + (z3*z3)

def createCoordinates():
    thisfile = open("points.txt")
    totalList = thisfile.readlines()
    pointsList = []
    for i in totalList:
        curr = i.split(' ')
        point = Point3(curr[0],curr[1],curr[2])
        #print '{0}, {1}, {2}'.format(curr[0],curr[1],curr[2])
        pointsList.append(point)
    return pointsList

def main():
    pointsList = createCoordinates()
    distance = 0
    center = Point3(0,0,0)
    for i in pointsList:
        temp = center.distance2(i)
        if(temp > distance):
            distance = temp
        #print 'Point is {0}, {1}, {2}'.format(i.x, i.y, i.z)
    
    #test = pointsList[0].distance2(pointsList[1])
    print distance


main()
